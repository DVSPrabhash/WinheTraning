﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare varibles
            int n;
            int rawTotal;
            int coloumTotal;
            int total = 0;

            //get the user input 
            Console.Write("Input the size of row and column of the table : ");
            n = Convert.ToInt32(Console.ReadLine());

            int[,] metrix = new int[n, n];

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    Console.Write("Input numbers : ");
                    metrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                coloumTotal = 0;

                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    Console.Write(metrix[i, j] + " ");
                    coloumTotal += metrix[i, j];

                }
                Console.WriteLine(coloumTotal);
                total += coloumTotal;
            }

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                rawTotal = 0;
                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    rawTotal += metrix[j, i];
                }
                Console.Write(rawTotal + " ");
                total += rawTotal;
            }
            Console.Write(total);

            Console.ReadKey();

        }
    }
}
