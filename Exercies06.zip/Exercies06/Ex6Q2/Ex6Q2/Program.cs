﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
         

            //declare arrays
            int[] array01 = new int[5];
            int[] array02 = new int[5];
            int[] array03 = new int[10];

            //get inputs for 1st array
            for (int i = 0; i < array01.Length; i++)
            {
                Console.Write("Enter values for 1st array : ");
                array01[i] = Convert.ToInt32(Console.ReadLine());
            }

            //get inputs for 2nd array
            for (int i = 0; i < array02.Length; i++)
            {
                Console.Write("Enter values for 2nd array : ");
                array02[i] = Convert.ToInt32(Console.ReadLine());
            }

            //call the MergeAndSort array
            array03 = MergeAndSort(array01, array02);

            //output
            for (int i = 0; i < array03.Length; i++)
            {
                Console.Write(array03[i] + " ");
            }

            Console.ReadKey();
        }

        static  int[] MergeAndSort(int[] array01, int[] array02)
        {

            int temp;

            //combined two arrays
            int[] combined = array01.Concat(array02).ToArray();

            //sort combined array
            for (int i = 1; i < combined.Length; i++)
            {
                for(int j = i; j > 0; j--)
                {
                    if (combined[j] < combined[j - 1])
                    {
                        temp = combined[j];
                        combined[j] = combined[j - 1];
                        combined[j - 1] = temp;
                    }
                }
                
            }
            
            return combined;
        }
    }
}
