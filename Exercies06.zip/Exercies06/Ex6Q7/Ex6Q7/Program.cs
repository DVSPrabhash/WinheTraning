﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q7
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.ReadKey();
        }

        static int[] ArrayDeclaration(int[] array)
        {
            int[] result = new int[10];
            return array;
        }

        static int[] AcceptArrayElement(int[] array)
        {
            for(int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter a value : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            return array;
        }

        static void DisplayArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i] + " ");               
            }
        }

        static Boolean SearchElementInArray(int[] array)
        {
            int inputValue;
            bool result = false;


            Console.WriteLine("Enter an element do you want to search : ");
            inputValue = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < array.Length; i++)
            {
                if (array[i] == inputValue)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        static void SortArray(int[] array)
        {
            int temp;

            for (int i = 1; i < array.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (array[j] < array[j - 1])
                    {
                        temp = array[j];
                        array[j] = array[j - 1];
                        array[j - 1] = temp;
                    }
                }

            }
        }

    }
}
