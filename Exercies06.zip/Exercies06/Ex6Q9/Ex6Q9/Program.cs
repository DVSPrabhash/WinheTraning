﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare the variables
            int numberOfRows;


            //get the user inputs
            Console.WriteLine("Enter the number of rows : ");
            numberOfRows = Convert.ToInt32(Console.ReadLine());

            //call the PrintPatten function
            PrintPattern(numberOfRows);

            Console.ReadKey();


        }

        static void PrintPattern(int numberOfRows)
        {
            int count = 1;

            for(int i = 1; i <= numberOfRows; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    
                    Console.Write(count + " ");
                    count++;
                }

                Console.WriteLine();
            }
           

        }
    }
}
