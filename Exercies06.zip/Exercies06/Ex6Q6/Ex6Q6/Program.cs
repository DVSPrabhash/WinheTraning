﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[5];
            int[] resultArray = new int[5];

            //get the user inputs
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write("Enter a number : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            //calling the MoveZeroToRight function
            resultArray = MoveZeroToRight(array);

            //print the result
            for(int i = 0; i < resultArray.Length; i++)
            {
                Console.Write(resultArray[i] + " ");
            }

            Console.ReadKey();
        }

        static int[] MoveZeroToRight(int[] array)
        {
            int temp;

            
            for(int i = 1; i < array.Length; i++)
            {
                for(int j = i; j > 0; j--)
                {             
                    if (array[j] == 0)
                    {
                        temp = array[j];
                        array[j] = array[j - 1];
                        array[j - 1] = temp; 
                    }
                }
               
            }

            return array;
        }
    }
}
