﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6Q5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare the variables
            int[] array = new int[4];
            Boolean value = true;

            //get the user inputs
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write("Enter a number : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            //check whether all index values are equels or not
            for (int i = array.Length - 1; i > 0; i--)
            {
                
               if (array[i] == array[i - 1])
                {
                    value = true;
                }
                else
                {
                    value = false;
                    break;
                }
            }

            if (value)
            {
                Console.WriteLine("All input values are equels ");
            }
            else
            {
                Console.WriteLine("Input values are not equels ");
            }

            Console.ReadKey();
        }

    }
}
