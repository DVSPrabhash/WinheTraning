﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GeneralPractitioner g1 = new GeneralPractitioner("sah", "123", "ds", "we", "wewe");
            Console.WriteLine(g1.ToString());

            Console.ReadKey();
        }
    }
}
