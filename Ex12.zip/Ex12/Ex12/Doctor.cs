﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex12
{
    internal class Doctor
    {
        //declare the variables
        protected string fullName;
        protected string registryNumber;
        protected string specialty;

        public Doctor(string fullName, string registryNumber, string specialty)
        {
            this.fullName = fullName;
            this.registryNumber = registryNumber;
            this.specialty = specialty;
        }
        public string GetName()
        {
            return fullName;
        }
        public string GetRegistryNumber()
        {
            return registryNumber;
        }
        public string GetSpecialty()
        {
            return specialty;
        }
        public void SetName(string fullName)
        {
            this.fullName = fullName;
        }
        public bool Equals(Doctor doctor)
        {
            if (this.registryNumber == doctor.registryNumber)
            {
                return true;
            }

            return false;
        }
        public string ToString()
        {
            return "Dr. " + fullName + ", Specialty : " + specialty;
        }
    }
}
