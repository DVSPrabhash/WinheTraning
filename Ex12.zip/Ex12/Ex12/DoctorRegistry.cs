﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Ex12
{
    internal class DoctorRegistry
    {
        private string province;
       private ArrayList doctors = new ArrayList();

        public DoctorRegistry(string province)
        {
            this.province = province;
        }
        public bool Register(Doctor doctor)
        {
            for (int i = 0; i < doctors.Count; i++)
            {
                if(doctors[i] == doctor)
                {
                    return false;
                }
               
            }
            doctors.Add(doctor);
            return true;
        }
        public bool DeRegister(string registerNumber)
        {
            for(int i = 0; i < doctors.Count; i++)
            {
                if (((Doctor)doctors[i]).GetRegistryNumber() == registerNumber)
                {
                    doctors.RemoveAt(i);
                    return true;
                }
            }

            return false;
        }
        public ArrayList GetDoctorList()
        {
            return doctors;
        }


    }
}
