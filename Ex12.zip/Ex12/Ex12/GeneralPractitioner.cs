﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex12
{
    internal class GeneralPractitioner : Doctor
    {
        private string practiceName;
        private string address;

        public GeneralPractitioner(string fullName, string registryNumber, string specialty, string practiceName, string address) : base(fullName, registryNumber, specialty)
        {
            this.practiceName = practiceName;
            this.address = address;
        }
        public string ToString()
        { 
            return base.ToString() + " Practice : " + practiceName;
        }
    }
}
