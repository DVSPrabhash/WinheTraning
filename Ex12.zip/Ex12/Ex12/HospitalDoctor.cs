﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex12
{
    internal class HospitalDoctor : Doctor
    {
        private string staffNumber;
        private string pagerNumber;

        public HospitalDoctor(string fullName, string registryNumber, string specialty, string staffNumber, string pagerNumber) : base(fullName, registryNumber, specialty)
        {
            this.staffNumber = staffNumber;
            this.pagerNumber = pagerNumber;
        }

        public string ToString()
        {
            return base.ToString() + " Pager : " + pagerNumber;
        }
    }
}
