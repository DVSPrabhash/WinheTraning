﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Circle c1 = new Circle(1);
            Console.WriteLine(c1.ToString());
            Console.ReadKey();
        }
    }
}
