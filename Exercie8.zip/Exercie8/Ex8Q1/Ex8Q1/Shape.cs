﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q1
{
    internal class Shape
    {
        private string color = "red";
        private bool filled = true;

        public Shape() { 

        }
        public Shape(string color, bool filled)
        {
            this.color = color;
            this.filled = filled;
        }
        public string GetColor()
        {
            return color;
        }
        public void SetColor(string color)
        {
            this.color = color;
        }
        public bool IsFilled()
        {
            return filled;
        }
        public void SetFilled(bool filled)
        {
            this.filled = filled;
        }
        public string ToString()
        {
            return "Shape[color = " + color + ", " + "filled = " + filled + "]";
        }
    }
}
