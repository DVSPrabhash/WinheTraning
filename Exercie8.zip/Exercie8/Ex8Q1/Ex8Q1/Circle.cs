﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q1
{
    internal class Circle : Shape
    {
        private double radius = 1.0;


        public Circle() : base()
        {

        }
        public Circle(double radius) : base()
        {
            this.radius = radius;
        }
        public Circle(double radius, string color, bool filled) : base(color, filled)
        {
            this.radius = radius;
        }
        public double GetRadius()
        {
            return radius;
        }
        public void SetRadius(double radius)
        {
            this.radius = radius;
        }
        public double GetArea()
        {
            return 3.14 * radius * radius;
        }
        public double GetPerimeter()
        {
            return 2 * 3.14 * radius;
        }
        public string ToString()
        {
            return "Circle[" + base.ToString()  + ", " + "radius = " + radius + "]";
        }

    }
}
