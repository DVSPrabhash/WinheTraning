﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q2
{
    internal class Animal
    {
        protected string name;

        public Animal(string name)
        {
            this.name = name;
        }   
        public  string ToString()
        {
            return "Animal[name = " + name + "]";
        }
    }
}
