﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q2
{
    internal class Dog : Animal
    {
        public Dog(string name) : base(name)
        {
            this.name = name;
        }
        public void Greets()
        {
            Console.Write("Woof");
        }
        public void Greets(Dog dog)
        {
            Console.Write("Woooof");
        }
        public string ToString()
        {
            return "Dog[" + base.ToString() + "]";
        }
    }
}
