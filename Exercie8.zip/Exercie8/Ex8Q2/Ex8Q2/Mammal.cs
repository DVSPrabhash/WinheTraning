﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q2
{
    internal class Mammal : Animal
    {
        public Mammal(string name) :base(name)
        {
            this.name = name;
        }

        public  string ToString()
        {
            return "Mammal[" + base.ToString() + "]";
        }
    }
}
