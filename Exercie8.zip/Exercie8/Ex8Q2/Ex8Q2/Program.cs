﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cat c = new Cat("ginger");
            Mammal m = new Mammal("Mam");
            Console.WriteLine(c.ToString() + "cat");
            Console.WriteLine(m.ToString() + "mammal");

            Console.ReadKey();
        }
    }
}
