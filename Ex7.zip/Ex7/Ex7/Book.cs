﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex7
{
    internal class Book
    {
        private String isbn;
        private String name;
        private Author author;
        private double price;
        private int qty = 0;

        public Book(string isbn, string name, Author author, double price)
        {
            this.isbn = isbn;
            this.name = name;
            this.author = author;
            this.price = price;           
        }
        public Book(string isbn, string name, Author author, double price, int qty)
        {
            this.isbn = isbn;
            this.name = name;
            this.author = author;
            this.price = price;
            this.qty = qty;
        }
        public String GetISBN()
        {
            return isbn;
        }
        public String GetName()
        {
            return name;
        }
        public Author GetAuthor()
        {
            return author;
        }
        public double GetPrice()
        {
            return price;
        }
        public void SetPrice(double price)
        {
            this.price = price;
        }
        public int GetQty()
        {
            return qty;
        }
        public void SetQty(int qty)
        {
            this.qty = qty;
        }
        public String GetAuthorName()
        {
            return author.GetName();
        }
        public String ToString()
        {
            return "Book[isbn = " + isbn + "name = " + name +  ", " + author.ToString() + ", " + "price = " + price + ", " + "qty = " + qty + "]"; 
        }
    }
}
