﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex7
{
    internal class Author
    {
        private String name;
        private String email;

        public Author(string name, string email)
        {
            this.name = name;
            this.email = email;
        }

        public String GetName()
        {
            return name;
        }
        public String GetEmail()
        {
            return email;
        }
        public void SetEmail(String email)
        {
            this.email = email;
        }
        public String ToString()
        {
            return "Author[name = " + name + ", " + "email = " + email + "]";
        }
    }
}
