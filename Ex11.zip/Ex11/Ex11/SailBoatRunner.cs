﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11
{
    internal class SailBoatRunner
    {
        static void Main(string[] args)
        {
            int sailboatSize;
            string sailboatName;
            string sailboatModel;
            int age;
            string name;
            int yearsOfExperience;
            int registryNumber;


            //get the user inputs
            Console.Write("Enter the boat name : ");
            sailboatName = Console.ReadLine();
            Console.Write("Enter the boat model : ");
            sailboatModel = Console.ReadLine();
            Console.Write("Enter the boat size in feet : ");
            sailboatSize = Convert.ToInt32(Console.ReadLine());

            //create sailboat object
            Sailboat sailboat = new Sailboat(sailboatSize, sailboatName, sailboatModel);

            //dislpay the data of sailboat
            Console.WriteLine(sailboat.ToString());

            //get the user inputs
            Console.Write("Enter the captian name : ");
            name = Console.ReadLine();
            Console.Write("Enter the captain's age : ");
            age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the years of experience : ");
            yearsOfExperience = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the registry number : ");
            registryNumber = Convert.ToInt32(Console.ReadLine());

            //create captain object
            Captain captain = new Captain(age, name, yearsOfExperience, registryNumber);
            sailboat.AssignCaptain(captain);
            Console.WriteLine(captain.ToString());
            //Console.WriteLine(sailboat.GetCaptain().ToString());

            Console.ReadKey();
         
        }
    }
}
