﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11
{
    internal class Sailboat
    {
        //declare the variables
        private int size;
        private string name;
        private string model;
        private Captain captain;

        public Sailboat(int size, string name, string model)
        {
            this.size = size;
            this.name = name;
            this.model = model;
            this.captain = null;
        }
        public bool AssignCaptain(Captain captain)
        {

            if(this.captain == null)
            {
                this.captain = captain;
                return true;
            }

            if(captain.GetYearsOfExperience() > this.captain.GetYearsOfExperience())
            {
                this.captain = captain;
                return true;
            }           
                return false;
            
        }
        public Captain GetCaptain()
        {
            return captain;
        }
        public bool Equals(Sailboat sailboat)
        {
            if(this.captain == null)
            {
                return false;
            }

            if(sailboat.name == this.name && sailboat.captain == this.captain)
            {
                return true;              
            }           
                return false;          
        }
        public string ToString()
        {
            if(this.GetCaptain() == null)
            {
                return "Relativity is a " + size + " feet " + model + " " + name + " with no captain.";
            }
            else
            {
                return "Relativity is a " + size + " feet" + model + " " + name + "; her captain is : " + captain.GetName();
            }
        }
    }
}
