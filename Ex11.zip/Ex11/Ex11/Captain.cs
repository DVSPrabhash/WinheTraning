﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11
{
    internal class Captain
    {
        //declare the variables
        private int age;
        private string name;
        private int yearsOfExperience;
        private int registryNumber;

        public Captain(int age, string name, int yearsOfExperience, int registryNumber)
        {
            this.age = age;
            this.name = name;
            this.yearsOfExperience = yearsOfExperience;
            this.registryNumber = registryNumber;
        }
        public string GetName()
        {
            return name;
        }
        public int GetYearsOfExperience()
        {
            return yearsOfExperience;
        }
        public bool Equals(Captain captain)
        {
           if(captain.name  == this.name && captain.registryNumber == this.registryNumber)
            { 
                return true;
            }
                return false;
        }
        public string ToString()
        {
            return name + ", age : " + age + "\nYoE : " + yearsOfExperience + "\nRegistry : " + registryNumber;
        }

    }
}
