﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5Q3
{
    internal class Program
    {
        
        static int[] Reverse(int[] array)
        {
            int[] reverseArray = new int[array.Length];
            int j = 0;

            for (int i = array.Length-1; i >= 0; i--)
            {               
                    reverseArray[j] = array[i]; 
                    j++;    
            }

            return reverseArray;
        }
        static void Main(string[] args)
        {
            int[] array = new int[10];
            int[] reverseArray = new int[10];

            //get user inputs
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter a number : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            //calling the reverse function
             reverseArray =  Reverse(array);

            //print the reverse array
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(reverseArray[i] + " ");
            }

            Console.ReadKey();
          
        }
    }
}
