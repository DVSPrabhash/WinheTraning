﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5Q6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number1;
            int number2;
            int number3;
            int number4;
            int total;

            for (int i = 1; i <= 500; i++)
            {           
                number1 = i / 100;
                number2 = i / 10;
                number3 = i % 10;
                number4 = number2 % 10;
                total = (number1 * number1 * number1) + (number3 * number3 * number3) + (number4 * number4 * number4);
                if(i == total)
                {
                    Console.WriteLine(i);
                }

            }
       
            Console.ReadKey();
        }
    }
}
