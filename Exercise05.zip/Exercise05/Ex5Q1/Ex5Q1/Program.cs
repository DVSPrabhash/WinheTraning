﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variable declaration
            int number01;
            int number02;
            int value = 1;

            //get the user inputs
            Console.WriteLine("Enter number 01 : ");
            number01 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number 02 : ");
            number02 = Convert.ToInt32(Console.ReadLine());

            //calculate the power value
            for (int i = 0; i < number02; i++)
            {
                value = value * number01;
            }


            //output
            Console.WriteLine(value);

            Console.ReadKey();
        }
    }
}
