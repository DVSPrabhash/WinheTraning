﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5Q2
{
    internal class Program
    {

        /*
         * calculateTemperature function get temperature value in fahernheit 
         * and it convert to celsius.
         * @params fahrenheitValue
         * @return double
         */
        static double CalculateTemperature(double fahrenheitValue)
        {
            double celsiusValue;
            celsiusValue = (fahrenheitValue - 32) * 5 / 9;

            return celsiusValue;
        }

        static void Main(string[] args)
        {
            //variable declaration
            double temperature;
            double result;

            //get the user inputs
            Console.WriteLine("Enter temperature vaule in fahernheit : ");
            temperature =  Convert.ToDouble(Console.ReadLine());

            //calling CalculateTemperature function
            result = CalculateTemperature(temperature);

            //output
            Console.WriteLine("Temperature vaule in celsius : " + Math.Round(result, 2));

            Console.ReadKey();
        }

    }
}
