﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3Q9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array01 = new int[10];
            int number;
            int temp;

            //User Inputs
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Enter a number : ");
                number = Convert.ToInt32(Console.ReadLine());
                array01[i] = number;
            }

            //Display Input Numbers
            for (int i = 0; i < array01.Length; i++)
            {
                Console.Write(array01[i] + " ");
            }

            Console.WriteLine();

            for (int i = 1; i < array01.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (array01[j] < array01[j - 1])
                    {
                        temp = array01[j];
                        array01[j] = array01[j - 1];
                        array01[j - 1] = temp;
                    }
                }
            }

            for (int i = 0; i < array01.Length; i++)
            {
                Console.Write(array01[i] + " ");
            }

            Console.ReadKey();
            
        }
    }
}
