﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3Q6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number = 1;
            int count = 0;
            int addition = 0;
            double average;

            while (number >= 0)
            {
                Console.WriteLine("Enter a positive integer number : ");
                number = Convert.ToInt32(Console.ReadLine());

                if (number >= 0)
                {
                    count++;
                    addition += number;
                    
                }                
            }

            average = addition / count;

            Console.WriteLine("Number of count is : " + count);
            Console.WriteLine("Total value is : " + addition);
            Console.WriteLine("The average value is : " + Math.Round(average, 2));

            Console.ReadKey();
        }
    }
}
