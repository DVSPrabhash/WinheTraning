﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int total = 0;

            for (int i = 1; i <= 10; i++)
            {
                total += i;
            }

            Console.WriteLine(total);

            Console.ReadKey();
        }
    }
}
