﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6OOP
{
    internal class ColoredPoint3D
    {
    }
}
