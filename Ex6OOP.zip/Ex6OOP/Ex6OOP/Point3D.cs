﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6OOP
{
    internal class Point3D : Point
    {
        protected int z; 

        public Point3D(): base()
        {
            z = 300;
        }

        public Point3D(int z, int x, int y):base(x, y)
        {
            this.z = z;
        }

        public override void SetValues()
        {
            z = 3000;
        }

       

    }
}
