﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Point c1 = new Point();
            c1.SetValueX(10);
            Console.Write(c1.GetValueX());
        }
    }
}
