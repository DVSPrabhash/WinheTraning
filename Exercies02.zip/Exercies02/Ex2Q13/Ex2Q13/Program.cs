﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            double radius;
            double height;
            double surfaceArea;
            double volume;

            //Get The Inputs
            Console.WriteLine("Enter The radius of the base in a cylinder : ");
            radius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter The height of a cylinder : ");
            height = Convert.ToDouble(Console.ReadLine());

            //Calculate The Surface Area
            surfaceArea = (2 * 3.14 * radius) * height;

            //Calculate The Volume
            volume = (3.14 * radius * radius) * height;

            //Output
            Console.WriteLine("Surface Area of the Cylinder is : " + surfaceArea);
            Console.WriteLine("Volume of the Cylinder is : " + volume);

            Console.ReadKey();

        }
    }
}
