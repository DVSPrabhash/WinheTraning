﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            String studentNumber;
            String studentName;
            double module01Marks;
            double module02Marks;
            double module03Marks;
            double totalMarks;
            double average;

            //Get The User Inputs
            Console.WriteLine("Enter The Student Number : ");
            studentNumber = Console.ReadLine();
            Console.WriteLine("Enter The Student Name : ");
            studentName = Console.ReadLine();
            Console.WriteLine("Enter The Module 01 Marks : ");
            module01Marks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter The Module 02 Marks : ");
            module02Marks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter The Module 03 Marks : ");
            module03Marks = Convert.ToDouble(Console.ReadLine());

            //Calculate The Total Marks
            totalMarks = module01Marks + module02Marks + module03Marks;

            //Calculate The Average Mark
            average = totalMarks / 3;

            //Output
            Console.WriteLine("Student Number is : " + studentNumber);
            Console.WriteLine("Student Name is : " + studentName);
            Console.WriteLine("Total Marks is : " + totalMarks);
            Console.WriteLine("Avarage Marks is : " + Math.Round(average, 2));
       

            Console.ReadKey();




        }
    }
}
