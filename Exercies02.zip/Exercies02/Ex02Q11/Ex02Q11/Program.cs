﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex02Q11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            double radius;
            double circumference;
            double area;

            //Get The Inputs
            Console.WriteLine("Enter the radius value : ");
            radius = Convert.ToDouble(Console.ReadLine());

            //Calculate The Circumference
            circumference = 2 * 3.14 * radius;

            //Calculate The Area
            area = 2 * 3.14  * radius * radius;

            //Output
            Console.WriteLine("Circumference is : " + circumference);
            Console.WriteLine("Area is : " + area);

            Console.ReadKey();

        }
    }
}
