﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            double radius;
            double height;
            double surfaceArea;
            double volume;
            double width;
            double perimeter;
            double area;
            double circumference;
            int inputValue;
            char loopValue = 'y';
            

            while (loopValue == 'y')
            {

                //Get The User Inputs
                Console.WriteLine("1.Circle = Enter number 1\n2.Rectangle = Enter number 2\n3.Cylinder = Enter number 3");
                Console.WriteLine("Enter one of number to do oparations : ");
                inputValue = Convert.ToInt32(Console.ReadLine());

                if (inputValue == 1)
                {
                    //Get The Inputs
                    Console.WriteLine("Enter the radius value : ");
                    radius = Convert.ToDouble(Console.ReadLine());

                    //Calculate The Circumference
                    circumference = 2 * 3.14 * radius;

                    //Calculate The Area
                    area = 2 * 3.14 * radius * radius;

                    //Output
                    Console.WriteLine("Circumference is : " + circumference);
                    Console.WriteLine("Area is : " + area);
                }
                else if (inputValue == 2)
                {

                    //Get The Inputs
                    Console.WriteLine("Enter the height of rectangle : ");
                    height = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the width of rectangle : ");
                    width = Convert.ToDouble(Console.ReadLine());

                    //Calculate The Perimeter of The Rectangle
                    perimeter = 2 * (width + height);

                    //Calculate The Area of The Reactangle
                    area = height * width;

                    //Output
                    Console.WriteLine("Perimeter of The Reactangle is : " + perimeter);
                    Console.WriteLine("Area of The Reactangle is : " + area);
                }
                else if (inputValue == 3)
                {
                    //Get The Inputs
                    Console.WriteLine("Enter The radius of the base in a cylinder : ");
                    radius = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter The height of a cylinder : ");
                    height = Convert.ToDouble(Console.ReadLine());

                    //Calculate The Surface Area
                    surfaceArea = (2 * 3.14 * radius) * height;

                    //Calculate The Volume
                    volume = (3.14 * radius * radius) * height;

                    //Output
                    Console.WriteLine("Surface Area of the Cylinder is : " + surfaceArea);
                    Console.WriteLine("Volume of the Cylinder is : " + volume);
                }
                else
                {
                    Console.WriteLine("Invalid Input Number");
                    return;
                }

                Console.WriteLine();
                Console.WriteLine("If you want to continue press 'y' If you want to exit press anyKey : ");
                loopValue = Convert.ToChar(Console.ReadLine());
                if (loopValue != 'y')
                {
                    return;
                }
            }


            Console.ReadKey();
        }
    }
}
