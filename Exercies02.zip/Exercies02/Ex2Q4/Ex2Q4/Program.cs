﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            int number01;
            int number02;
            int total;

            //Get The User Input
            Console.WriteLine("Enter Number 01 : ");
            number01 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number 02 : ");
            number02 = Convert.ToInt32(Console.ReadLine());

            //Calculate Number01+Number02 Value
            total = number01 + number02;

            //Output
            Console.WriteLine("The Sumation Of Number 01 and Number 02 is : " + total);

            Console.ReadKey();

        }
    }
}
