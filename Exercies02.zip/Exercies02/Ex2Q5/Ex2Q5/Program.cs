﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variables
            String salesmanNumber;
            String salesmanName;
            int noOfUnitsSold;
            double unitPrice;
            double salesValue;

            //Get The User Inputs
            Console.WriteLine("Enter The Salessman Number : ");
            salesmanNumber = Console.ReadLine();
            Console.WriteLine("Enter The Salesman Name : ");
            salesmanName = Console.ReadLine();
            Console.WriteLine("Enter Number Of Units Sold : ");
            noOfUnitsSold = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter The Unit Price : ");
            unitPrice = Convert.ToDouble(Console.ReadLine());

            //Calculate The SalesValue
            salesValue = unitPrice * noOfUnitsSold;

            //Output
            Console.WriteLine("Salesman Number is : " + salesmanNumber);
            Console.WriteLine("Salesman Name is : " + salesmanName);
            Console.WriteLine("SalesValue is : " + salesValue);

            Console.ReadKey();
        }
    }
}
