﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            String name;

            //Get Input From The User
            Console.WriteLine("Enter Your Name : ");
            name = Console.ReadLine();

            //Output
            Console.WriteLine("Hello " + name);

            Console.ReadKey();
        }
    }
}
