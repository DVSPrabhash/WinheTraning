﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2Q12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variable Declaration
            double height;
            double width;
            double perimeter;
            double area;

            //Get The Inputs
            Console.WriteLine("Enter the height of rectangle : ");
            height = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the width of rectangle : ");
            width = Convert.ToDouble(Console.ReadLine());

            //Calculate The Perimeter of The Rectangle
            perimeter = 2 * (width + height);

            //Calculate The Area of The Reactangle
            area =  height * width;

            //Output
            Console.WriteLine("Perimeter of The Reactangle is : " + perimeter);
            Console.WriteLine("Area of The Reactangle is : " + area);

            Console.ReadKey();  
        }
    }
}
