﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //calling RunMenu function
            RunMenu();

            Console.ReadKey();  
        }


        static void RunMenu()
        {
            //variable declaration
            int choose = 0;
            int temp = 0;
            string output = "";
            int[,] result = new int[100, 10];


            while (choose != 1) {

                //diplaying instractions before user enter inputs
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("\tThe Progress Statistics Genarator\t");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("[1] End Testing The Program");
                Console.WriteLine("[2] Display 'About' Information");
                Console.WriteLine("[3] Read and Store Data From Files");
                Console.WriteLine("[4] Genarate a Results Data Table");
                Console.WriteLine("[5] Save Results Statistics to a File");
                Console.WriteLine("[6] Display Results Statistics From a File");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                //get user input
                Console.Write("Which option would you like (1-6) : ");
                choose = Convert.ToInt32(Console.ReadLine());

                //options selection
                if (choose == 1)
                {
                    Console.WriteLine();
                    Console.WriteLine("Thank you for testing this application.");
                }
                else if (choose == 2)
                {
                    //calling DisplayText function
                    DisplayText("About.txt");
                }
                else if (choose == 3)
                {
                    //calling the CreateLists function
                     result = CreateLists("Results.txt");
     
                    //print the matrix
                    for (int a = 0; a < result.GetLength(0); a++)
                    {
                        for (int b = 0; b < result.GetLength(1); b++)
                        {
                            Console.Write(result[a, b] + "\t");
                        }
                        Console.WriteLine();
                    }
                   
                    temp = 1;

                    Console.WriteLine();
                    Console.WriteLine("\tPress any key to continue...");
                    Console.ReadKey();
                }
                else if (choose == 4)
                {
                    //this condition use to check user chosse opition 4 before choosing option 3
                    if (temp == 1)
                    {                       
                        //calling GenerateTable function
                        output = GenerateTable(result);
                        Console.WriteLine(output);
                        Console.WriteLine();
                        Console.WriteLine("\tPress any key to continue...");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Please select option[3] to first load data!");
                        Console.WriteLine();
                        continue;
                    }
                    
                }
                else if(choose == 5)
                {               
                    //calling SaveData function
                    SaveData(output);

                    Console.WriteLine();
                    Console.WriteLine("\tPress any key to continue...");
                    Console.ReadKey();
                }
                else if(choose == 6)
                {
                    DisplayData();

                    Console.WriteLine();
                    Console.WriteLine("\tPress any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("\n\tInvalid User Input!!");
                    Console.WriteLine();
                    Console.WriteLine("   Press any key to back to the menu...");
                    Console.ReadKey();
                }

            }
         
        }



        static void DisplayText(string fileName)
        {
            string[] lines = File.ReadAllLines(@"D:\VisualStudioWorkspace\Ex10\Ex10\" + fileName);

            //display the all data in the file           
            foreach (string line in lines)
            {                
                Console.WriteLine(line);
            }

            Console.WriteLine("\tPress any key to continue...");
            Console.ReadKey();
        }



        static int[,] CreateLists(string fileName)
        {

            string text = File.ReadAllText(@"D:\VisualStudioWorkspace\Ex10\Ex10\" + fileName);

            int i = 0;
            int j = 0;
            int[,] result = new int[100, 10];

            foreach (string row in text.Split('\n'))
            {
                j = 0;

                foreach (string col in row.Trim().Split('\t'))
                {
                    result[i, j] = int.Parse(col.Trim());                 
                    j++;                 
                }

                //avoid outbound exception i == 100
                if (i == 99)
                {
                    break;
                }
                i++;

            }

            return result;
        }



        static string GenerateTable(int[,] result)
        {
            int noOfStudent;
            int randomNumber;
            string HD = "";
            string D = "";
            string CR = "";
            string P = "";
            string F = "";
            string output;

            Console.Write("Enter number of student: ");
            noOfStudent = Convert.ToInt32(Console.ReadLine());

            Random rnd = new Random();
            randomNumber = rnd.Next(1, 10);
       
            //print the matrix

            for(int i = 0; i < noOfStudent; i++)
            {
                if(result[i, randomNumber] > 75)
                {
                    HD += "*";
                }
                else if (result[i, randomNumber] > 65)
                {
                    D += "*";
                }
                else if (result[i, randomNumber] > 55)
                {
                    CR += "*";
                }
                else if (result[i, randomNumber] > 45)
                {
                    P += "*";
                }
                else
                {
                    F += "*";
                }

            }

            output = "You have entered " + noOfStudent + " students." + "\n" +
                     "Assesment " + randomNumber + " has been selected randomly." + "\n" +
                     "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" +
                     "HD: " + HD + "\n" + "D : " + D + "\n" + "CR: " + CR + "\n" + "P : " + P
                     + "\n" + "F : " + F + "\n";

            return output;

        }

        static void SaveData(string output)
        {
            char input;

            //display the last genarated staticstic table
            Console.WriteLine(output);
            Console.WriteLine("Do you want to save this data? (y/n): ");
            input =  Convert.ToChar(Console.ReadLine());

            if (input == 'y')
            {
                //save the data in file
                File.AppendAllText(@"D:\VisualStudioWorkspace\Ex10\Ex10\SavedProgressData.txt", output);
            }
            else
            {
                return;
            }
        }

        static void  DisplayData()
        {
            string text = File.ReadAllText(@"D:\VisualStudioWorkspace\Ex10\Ex10\SavedProgressData.txt");
            Console.WriteLine();
            Console.WriteLine("All Saved Statistics\n" + text);
        }

    }
}
